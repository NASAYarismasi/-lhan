Node.js ve Python ile arşiv kökünde PowerShell aç.
npm install --prefix work/mars-tools
& work/build-mars.ps1 -FirstPerson
Çıktı: outputs/MARS-KOLONI-FPS.html
