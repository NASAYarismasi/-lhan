UTF-8

FPS demosunu yeniden derlemek için arşiv kökünde PowerShell aç.

npm install --prefix work/mars-tools
& work/build-mars.ps1 -FirstPerson

Sonuç: outputs/MARS-KOLONI-FPS.html
