param([switch]$FirstPerson, [string]$Portrait)
$ErrorActionPreference = 'Stop'
$env:NODE_PATH = (Resolve-Path work/mars-tools/node_modules).Path
work/mars-tools/node_modules/.bin/esbuild.cmd work/mars-demo.mjs --bundle --format=iife --define:import.meta.url=document.baseURI --minify --legal-comments=inline --outfile=work/mars-bundle.js
if ($LASTEXITCODE) { exit $LASTEXITCODE }
@'
from pathlib import Path
import base64, re, sys
p = Path("work")
draco = p / "mars-tools/node_modules/three/examples/jsm/libs/draco/gltf"
html = (p / "mars-template.html").read_text(encoding="utf-8")
parts = {
    "ROVER": base64.b64encode((p / "perseverance.glb").read_bytes()).decode(),
    "HABITAT": base64.b64encode((p / "habitat-nasa.glb").read_bytes()).decode(),
    "INSIGHT": base64.b64encode((p / "insight.glb").read_bytes()).decode(),
    "INGENUITY": base64.b64encode((p / "ingenuity.glb").read_bytes()).decode(),
    "ORTHO": base64.b64encode((p / "jezero-ortho.webp").read_bytes()).decode(),
    "FACE": base64.b64encode(Path(sys.argv[2]).read_bytes()).decode() if len(sys.argv) > 2 and sys.argv[2] else "",
    "TEAMCREW": base64.b64encode((p / "team-astronaut.glb").read_bytes()).decode(),
    "TEAMWRIST": base64.b64encode((p / "team-astronaut.stl").read_bytes()).decode(),
    "DECODER": (draco / "draco_wasm_wrapper.js").read_text(encoding="utf-8"),
    "WASM": base64.b64encode((draco / "draco_decoder.wasm").read_bytes()).decode(),
    "BUNDLE": (p / "mars-bundle.js").read_text(encoding="utf-8"),
}
for key, value in parts.items():
    assert not re.search(r"</script", value, re.I)
    html = html.replace("/* " + key + " */", value)
first_person = len(sys.argv) > 1 and sys.argv[1] == "fps"
if first_person:
    html = html.replace('<main>', '<main data-start-view="fps">', 1)
    html = html.replace('<title>Mars’a İlk Koloni</title>', '<title>Mars’a İlk Koloni · FPS</title>', 1)
name = "MARS-JEZERO-ASTRONOT.html" if parts["FACE"] else "MARS-KOLONI-FPS.html" if first_person else "MARS-KOLONI.html"
Path("outputs", name).write_text(html, encoding="utf-8")
'@ | python - $(if ($FirstPerson) { 'fps' } else { 'plan' }) $Portrait
exit $LASTEXITCODE
