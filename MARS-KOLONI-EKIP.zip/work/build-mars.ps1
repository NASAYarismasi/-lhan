param([switch]$FirstPerson)
$ErrorActionPreference = 'Stop'
$env:NODE_PATH = (Resolve-Path work/mars-tools/node_modules).Path
work/mars-tools/node_modules/.bin/esbuild.cmd work/mars-demo.mjs --bundle --format=iife --define:import.meta.url=document.baseURI --minify --legal-comments=inline --outfile=work/mars-bundle.js
if ($LASTEXITCODE) { exit $LASTEXITCODE }
@'
from pathlib import Path
import base64, re, sys
p = Path("work")
draco = p / "mars-tools/node_modules/three/examples/jsm/libs/draco/gltf"
html = (p / "mars-template.html").read_text(encoding="utf-8")
parts = {
    "ROVER": base64.b64encode((p / "perseverance.glb").read_bytes()).decode(),
    "HABITAT": base64.b64encode((p / "habitat-nasa.glb").read_bytes()).decode(),
    "INSIGHT": base64.b64encode((p / "insight.glb").read_bytes()).decode(),
    "DECODER": (draco / "draco_wasm_wrapper.js").read_text(encoding="utf-8"),
    "WASM": base64.b64encode((draco / "draco_decoder.wasm").read_bytes()).decode(),
    "BUNDLE": (p / "mars-bundle.js").read_text(encoding="utf-8"),
}
for key, value in parts.items():
    assert not re.search(r"</script", value, re.I)
    html = html.replace("/* " + key + " */", value)
first_person = len(sys.argv) > 1 and sys.argv[1] == "fps"
if first_person:
    html = html.replace('<main>', '<main data-start-view="fps">', 1)
    html = html.replace('<title>Mars’a İlk Koloni</title>', '<title>Mars’a İlk Koloni · FPS</title>', 1)
name = "MARS-KOLONI-FPS.html" if first_person else "MARS-KOLONI.html"
Path("outputs", name).write_text(html, encoding="utf-8")
'@ | python - $(if ($FirstPerson) { 'fps' } else { 'plan' })
exit $LASTEXITCODE
