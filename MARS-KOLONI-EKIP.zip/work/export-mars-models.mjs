import { mkdir, writeFile } from "node:fs/promises"
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js"
import { moduleModel, terrainModel } from "./mars-models.mjs"
import { modules } from "../outputs/mars-koloni.mjs"

// GLTFExporter expects the browser FileReader API for final Blob encoding.
globalThis.FileReader = class {
  async readAsArrayBuffer(blob) {
    this.result = await blob.arrayBuffer()
    this.onloadend()
  }
}
const folder = process.argv[2]
await mkdir(folder, { recursive: true })
for (const [name, model] of [
  ["jezero-mola", terrainModel()],
  ...Object.keys(modules).map(id => [id, moduleModel(id)]),
]) {
  const result = await new GLTFExporter().parseAsync(model, { binary: true })
  await writeFile(folder + "/" + name + ".glb", Buffer.from(result))
}
